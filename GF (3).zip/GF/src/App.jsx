import React from "react";

import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ProductList from "./pages/ProductList";
import CreateProduct from "./pages/CreateProduct";
import UpdateProduct from "./pages/UpdateProduct";
import Navber from "./pages/Navber";
import Footer from "./pages/Footer";
import Home from "./pages/Home";


const App = () => {
  return (
    <Router>
      <Navber/>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/list" element={<ProductList />} />
        <Route path="/create" element={<CreateProduct />} />
        <Route path="/update/:id" element={<UpdateProduct />} />
      </Routes>
      <Footer/>
    </Router>
  );
};

export default App;
