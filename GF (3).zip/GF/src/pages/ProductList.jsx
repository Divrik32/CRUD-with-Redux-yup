import  { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { deleteProduct, fetchProducts } from '../redux/ProductSlice';
import '../style/Style.css'
const ProductList = () => {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.products);
  const navigate=useNavigate()
  useEffect(() => {
    dispatch(fetchProducts());
  }, [dispatch]);

  const handleDelete = (id) => {
    dispatch(deleteProduct(id));
  };

  return (
    <div>
      <h1>Product List</h1>
      <Link to="/create"><button className='create' style={{borderRadius:'15px 0 15px',padding:'5px'}}>Create Product</button></Link><br /><br />
 
          <table >
              <tr >
                <th>Product Name</th>
                <th>Price</th>
                <th>Product Details</th>
                <th>Action</th>
                <th>Action</th>

              </tr>
              {products.map((product) => (

              <tr key={product.id}>
                <td>{product.productName}</td>
                <td>{product.price}</td>
                <td>{product.productDetails}</td>
                <td><button className='action1' style={{borderRadius:'10px 0 10px'}} onClick={()=>navigate(`/update/${product.id}`)}>Edit</button></td>
                <td><button className='action' style={{borderRadius:'10px 0 10px'}} onClick={() => handleDelete(product.id)}>Delete</button></td>
              </tr>
        ))}

          </table>
    </div>
  );
};

export default ProductList;
