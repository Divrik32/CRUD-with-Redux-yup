import React from "react";
import { Link } from "react-router-dom";
import '../style/Home.css'

const Home = () => {
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6">
          <img
            src="src\images\homeImage.jpg"
            style={{ marginTop: "20px" }}
            height={500}
            width={500}
            alt=""
          />
        </div>
        <div className="col-md-6">
          <Link  to="/create">
            <button className="home" style={{margin:'120px 100px 100px 150px',padding:'20px',borderRadius:'50%'}}>Create Product</button>
          </Link>
          <br />
          <Link to="/list">
            <button className="home1" style={{margin:'60px 100px 100px 150px',padding:'20px',borderRadius:'50%'}}>Product List</button>
          </Link>
          
        </div>
      </div>
    </div>
  );
};

export default Home;
