import  { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import { updateProduct } from '../redux/ProductSlice';
import axios from 'axios';



const schema = yup.object().shape({
  productName: yup.string().required(),
  productDetails: yup.string().required(),
  price: yup.number().positive().required(),
});

const UpdateProduct = () => {

  const { id } = useParams();
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [productDetails, setProductDetails] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const product = useSelector((state) =>
    state.products.find((product) => product.id === parseInt(id))
  );
  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    const fetchProduct = async () => {
      var response = await axios.get(`http://localhost:3000/products/${id}`);
      console.log(response);
      setProductName(response.data.productName);
      setPrice(response.data.price);
      setProductDetails(response.data.productDetails);
    };
    fetchProduct();
  }, [id]);
  // console.log(response);

  useEffect(() => {
    if (product) {
      setValue('productName', product.productName);
      setValue('productDetails', product.productDetails);
      setValue('price', product.price);
    }
  }, [product, setValue]);
  const onSubmit = (data) => {
    dispatch(updateProduct({ id: id, product: data }));
    navigate('/list');
  };

  return (
    <div >
    <form className="container" style={{background:'#2d3e3f',marginTop:'100px',paddingTop:'25px',width:'400px',height:'300px',textAlign:'center'}}  onSubmit={handleSubmit(onSubmit)}>
     <label htmlFor="" style={{color:'white',fontSize:'25px',marginBottom:'15px'}}> Update Product</label>
    <div className="box">
    <label for="createProduct" class="fl fontLabel"> Product Name </label>			
      <input {...register("productName")} placeholder={productName}  autofocus="on" required/>
      <p>{errors.productName?.message}</p>
      </div>

      <div className="box">
      <label for="productDetails" class="fl fontLabel"> Product Details </label>
      <input {...register("productDetails")} placeholder={productDetails} autofocus="on" required/>
      <p>{errors.productDetails?.message}</p>
      </div>

      <div className="box">
      <label for="price" class="fl fontLabel"> Price </label>
      <input type="number" {...register("price")} placeholder={price} autofocus="on" required/>
      <p>{errors.price?.message}</p>
      </div>
      <br />
      <button type="submit" className="create">Update Product</button>
    </form>
    </div>
  );
};

export default UpdateProduct;
