import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useDispatch } from "react-redux";
import { createProduct } from "../redux/ProductSlice";
import { useNavigate } from "react-router-dom";
import '../style/Create.css'

const schema = yup.object().shape({
  productName: yup.string().required(),
  productDetails: yup.string().required(),
  price: yup.number().positive().required(),
});

const CreateProduct = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = (data) => {
    dispatch(createProduct(data));
    navigate("/list")
  };

  return (
  <div >
    <form  className="container" style={{background:'#2d3e3f',marginTop:'100px',paddingTop:'60px',width:'400px',height:'300px',textAlign:'center'}}  onSubmit={handleSubmit(onSubmit)}>
    
    <div className="box">
    <label for="createProduct" class="fl fontLabel"> Product Name </label>			
      <input {...register("productName")} placeholder="Product Name" autofocus="on" required/>
      <p>{errors.productName?.message}</p>
      </div>

      <div className="box">
      <label for="productDetails" class="fl fontLabel"> Product Details </label>
      <input {...register("productDetails")} placeholder="Product Details" autofocus="on" required/>
      <p>{errors.productDetails?.message}</p>
      </div>

      <div className="box">
      <label for="price" class="fl fontLabel"> Product Price </label>
      <input type="number" {...register("price")} placeholder="Price" autofocus="on" required/>
      <p>{errors.price?.message}</p>
      </div>
      <br />
      <button type="submit" className="create">Create Product</button>
    </form>
    </div>
  );
};

export default CreateProduct;
