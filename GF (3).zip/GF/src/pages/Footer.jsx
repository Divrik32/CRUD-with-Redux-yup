// Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer style={footerStyle}>
      <p>&copy; 2024 Your Company Name. All rights reserved.</p>
      <nav>
        <a href="#">Home</a> |
        <a href="#">About</a> |
        <a href="#">Contact</a>
      </nav>
    </footer>
  );
}

// CSS in JS for footer styles
const footerStyle = {
  backgroundColor: '#333',
  color: '#fff',
  padding: '20px',
  textAlign: 'center',
  position: 'fixed',
  bottom: '0',
  width: '100%'
};

export default Footer;
